﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace WindowsFormsApplication2
{
    public partial class Connect : Form
    {
        public SerialPort serialPort;
        public Connect()
        { 
            InitializeComponent();
            // all the serial ports are stored in an strings array
            string[] ArrayComPortsNames = null;
            // get the serial ports available
            ArrayComPortsNames = SerialPort.GetPortNames();
            // clear just to be sure
            comboBox4.Items.Clear();
            // add each port found to the drop down list from the GUI
            foreach (string portName in ArrayComPortsNames)
            {
                comboBox4.Items.Add(portName);
            }
        }
        // establish a serial connection with the ardunio and display the view
        // where you can send the data to the arduino
        private void button1_Click(object sender, EventArgs e)
        {

            // get the port name from the combobox
            serialPort1.PortName = comboBox4.Text;
            // get the baud rate from the combobox
            serialPort1.BaudRate = int.Parse(comboBox1.Text);
            // TO-DO : uncomment later
            // get the number of bits from the combobox
            //serialPort1.DataBits = comboBox2.Text;
            // get the parity of bits from the combobox
            //serialPort1.Parity = comboBox2.Text;
            // get the stop bits from the combobox
            //serialPort1.StopBits = comboBox2.Text;

            // in order to establish a serial connection, the port must be open
            serialPort1.Open();
            // open the second form where you can introduce the data to be sent
            AfterConnect form = new AfterConnect();
            // pass the serialPort1 to the second form
            form.setSerialPort(serialPort1);
            //display the form
            form.Show();
        }
    }
}
    