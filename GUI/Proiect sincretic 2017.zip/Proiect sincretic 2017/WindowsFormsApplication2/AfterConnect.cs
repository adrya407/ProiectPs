﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class AfterConnect : Form
    {
        // declaring a public serial port so it can be set from the other form
        public SerialPort myPort;
        public AfterConnect()
        {
            InitializeComponent();
        }
        // this method will be called from the first porm in order to pass the serialPort1
        public void setSerialPort(SerialPort port)
        {
            myPort = port;
        }
        // when the send button is pressed, the text from the textbox will be sent to arduino
        private void button1_Click(object sender, EventArgs e)
        {
            myPort.WriteLine(textBox1.Text);
        }
    }
}
